package com.cg.banking.daoservices;

import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public interface AccountDAO {
	Account save(Account account) ;
	Account findOne(long accountNo);
	ArrayList<Account> findAll() ;
	ArrayList<Transaction>findAccountAllTransactions(long accountNo) ;
	Transaction save(Transaction transaction);
	boolean updateAccount(Account account);
}