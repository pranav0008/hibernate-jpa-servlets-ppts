package com.cg.banking.daoservices;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public class AccountDAOImpl implements AccountDAO {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public Account save(Account account){
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	@Override
	public Account findOne(long accountNo){
		EntityManager entityManager = factory.createEntityManager();
		return entityManager.find(Account.class, accountNo);
	}

	@Override
	public ArrayList<Account> findAll(){
		EntityManager entityManager = factory.createEntityManager();
		Query query = entityManager.createQuery("from Account a");
		ArrayList<Account>list=(ArrayList<Account>)query.getResultList();
		return list;
		}

	@Override
	public ArrayList<Transaction> findAccountAllTransactions(long accountNo)
			 {EntityManager entityManager = factory.createEntityManager();
				Query query = entityManager.createQuery("from Transaction a");
				ArrayList<Transaction> list=(ArrayList<Transaction>)query.getResultList();
				return list;
	}

	@Override
	public Transaction save(Transaction transaction){
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;	
	}		@Override
	public boolean updateAccount(Account account) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;

	}  

}

