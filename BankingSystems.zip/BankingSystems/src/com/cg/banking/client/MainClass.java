package com.cg.banking.client;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.exceptions.TransactionRollbackException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {

	public static void main(String[] args) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidAmountException, InvalidAccountTypeException, InvalidPinNumberException, AccountBlockedException, TransactionRollbackException {
		/*Address address = new Address("Pune","Maharashtra","India",411057);
		address.getCity();
		Address address2 = new Address(address.getCity(),address.getState(), null, 0);
		System.out.println(address2.getCity());
		System.out.println(address.getCity());
		*/
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		System.out.println("efgs");
		BankingServices bs = new BankingServicesImpl();
		AccountDAO dao = new AccountDAOImpl();
		Account account1 = new Account();
		Transaction transaction = new Transaction();
		account1 = bs.openAccount(5600,"Saving", 10000);
		System.out.println(account1);
		System.out.println(bs.depositAmount(1, 5000));
		System.out.println(bs.withdrawAmount(account1.getAccountNo(), 5000, account1.getPinNumber()));
		Account account2 = new Account();
		account2 = bs.openAccount(5633,"Saving",5000);
		System.out.println(account2);
		bs.fundTransfer(account1.getAccountNo(), account2.getAccountNo(), 1000,account2.getPinNumber());
		System.out.println(bs.getAccountDetails(account1.getAccountNo()));
		System.out.println(bs.getAccountAllTransaction(account1.getAccountNo()));
		System.out.println(bs.getAllAccountDetails());
		
		//System.out.println(bs.depositAmount(1, 5000));
		
	
	}

}
